﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GoodNamesMatch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name1;
            string name2;
            double sumPerc = 0;

            //Console.WriteLine("Enter name 1");
            //name1 = Console.ReadLine();
            //Console.WriteLine("Enter name 2");
            //name2 = Console.ReadLine();

            //string uName1 = name1.ToLower();
            //string uName2 = name2.ToLower();

            //Decode(uName1, uName2);
            readRecord();
            Console.Read();
        }

        public static string addRecord(string name, int name1)
        {

            string filePath = @"C:\Users\XLTVNE\Documents\2022 Academic\PPC115C\Practical\GoodNamesMatch\GoodNamesMatch\bin\Debug\output.txt";
            FileStream stream = null;

            try
            {
                stream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);

                using (StreamWriter writer = new StreamWriter(stream, Encoding.UTF8))
                {
                    int i = 0;
                    i++;
                    writer.WriteLine($"Match Maker Results #00{i}");
                    writer.WriteLine("=================================================");
                    writer.WriteLine($"{name} = {name1}"); 
                    writer.WriteLine($"{name} = {name1}");
                }
            }

            catch (IOException ex)
            {
                Console.WriteLine("IO Exception was thrown");
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                if (stream != null)
                {
                    stream.Dispose();
                }
            }
            return name +" "+ name1;

        }


        public static void readRecord()
        {
            string[] recordNotFound = { "Record not found" };
            string line;
            string pathS = @"C:\Users\XLTVNE\Documents\2022 Academic\PPC115C\Practical\GoodNamesMatch\GoodNamesMatch\bin\Debug\Data.csv";
            

            try
            {
                using (FileStream myFile = new FileStream(@"C:\Users\XLTVNE\Documents\2022 Academic\PPC115C\Practical\GoodNamesMatch\GoodNamesMatch\bin\Debug\Data.csv", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                {

                    using (StreamReader str = new StreamReader(myFile))
                    {
                        line = str.ReadLine();

                        List<string> males = new List<string>();
                        List<string> females = new List<string>();
                        string aMales = "";
                        string aFemales = "";

                        //Read data line by line

                        Console.WriteLine("Female \t Male");
                        while (!str.EndOfStream)
                        {
                            line = str.ReadLine();
                            string[] values = line.Split(';');


                            if (values[1].Equals("m"))
                            {
                                males.Add(values[0]);


                                for (int i = 0; i < values[0].Length; i++)
                                {
                                    if (values[0] == values[0] && values[1] == values[1])
                                    {
                                        values[0].Distinct();
                                        values[1].Distinct();
                                    }
                                }
                                //Console.WriteLine(values[0]);
                                aMales = values[0];
                            }
                            else if (values[1] == "f")
                            {
                                for (int i = 0; i < values[0].Length; i++)
                                {
                                    if (values[0] == values[0] && values[1] == values[1])
                                    {
                                        values[0].Distinct();
                                        values[1].Distinct();
                                    }
                                }
                                //Console.Write(values[0]);
                                aFemales = values[0];

                            }
                            //Console.WriteLine($"{aFemales}  {aMales}");
                            Decode(aFemales, aMales);
                        }

                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("An IO Exception has been thrown!");
                Console.WriteLine(ex.ToString());
 
            }
        }


        static string Decode(string name1, string name2)
        {
            /*
             * Add Method comments
             */
            double[] countChar = new double[] { };
            string findMatch = name1 + " matches " + name2;
            int num = 0;
            string answer = "";
            Console.WriteLine(findMatch);
            while (findMatch.Length > 0)
            {
                int charCount = 0;

                //Console.Write($"{findMatch[0]}");
                for (int i = 0; i < findMatch.Length; i++)
                {
                    if (findMatch[0] == findMatch[i])
                    {
                        charCount++;
                        answer = Convert.ToString(charCount);
                    }
                    addRecord(name1 + " matches " + name2, num);
                }
                num = charCount;
                Console.Write($"{charCount} ");

                findMatch = findMatch.Replace(findMatch[0].ToString(), string.Empty);
                findMatch = findMatch.Trim();
            }
                Console.Write($" jj{sumNumbers(num)} ");
            return answer + " - " + name1 + ""+ name2;
        }

        public static int sumNumbers(int number)
        {
            int r = 0, sum = 0;

            while (number > 0 || sum > 100)
            {
                if (number == 10)
                {
                    number =sum;
                    sum = 0;
                }
                r = number % 10;
                sum += r;
                number /= 10;
            }
            //if(sum > 10)
            //{
            //    sum = sumNumbers(sum);
            //}    

            return sum;
            //r = number % 10;
            //number = number / 10;
            //sum = r;
        }
    }
}
